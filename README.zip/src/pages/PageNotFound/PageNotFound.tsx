export const PageNotFound = () => {
    return <div>404 page not found</div>
}