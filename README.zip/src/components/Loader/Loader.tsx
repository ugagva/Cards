import React from 'react';
// @ts-ignore
import s from './Loader.module.css'

const Loader = () => {
    return (
        <div className={s.loader}></div>
    );
};

export default Loader;
